Passos para instalação do Projeto PWS
1º - Instalar o workbech ou uma aplicação de serviço com servidor Apache e MySql
2º - Criar um utilizador no MySql chamado pwa com a password pwa
3º - Correr a base de dados que se encontra no diretório /database/PwsAeroporto.sql
4º - O primeiro user é automaticamente registado sendo o seu user adminmaster e a sua password adminmaster (utilizandor com perfil de aministrador)
5º - Ao criar novos users, o administrador deve atribuir um tipo de perfil para que as suas funcionalidades fiquem corretas consoante o seu tipo de perfil


!!!!ATENÇÃO!!!!
6º - O relatório encontra-se na diretoria /doc/IPL-TeSP-PSI-MDS-2021-Template_Projeto_PWS.docx

# PSI_PWS_PL1-A
--------------------------------

# Descrição do projeto

No âmbito da unidade curricular de MDS do 2º Semestre do Curso TeSP de Programação de Sistemas de Informação do Instituto Politécnico de Leiria, foi criado o projeto “Website de Compra de Viagens”, que consiste na elaboração de uma website que gere todo o tipo de viagens.

Assim, para a Unidade Curricular de Programação Web Servidor, o objetivo do projeto é a criação e desenvolvimento do Website e para a Unidade Curricular Metodologias de Desenvolvimento de Software, o objetivo passa por fazer a gestão do projeto anteriormente referido. 

O projeto é comum entre ambas as disciplinas, mas as fases que traçam este projeto são divididas pelas duas, conforme a sua pertinência.


## Membros da Equipa

* Diogo Pereira Nº 2201126
* Gabriel Silva Nº 2201133
* Gonçalo Ferreira Nº 2201131

## Imagem da instituição

![IPL](doc/logoipl.png)
